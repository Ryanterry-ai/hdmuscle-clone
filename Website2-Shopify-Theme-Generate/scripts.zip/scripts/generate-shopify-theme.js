const fs = require('fs-extra');
const path = require('path');

const TARGET_URL = process.argv[2] || 'https://hdmuscle.com';
const DOMAIN = new URL(TARGET_URL).hostname.replace('www.', '');
const THEME_NAME = `${DOMAIN.replace('.com','')}-theme`;

const OUTPUT_DIR = path.join(__dirname, '..', 'output', THEME_NAME);
const SOURCE_DIR = path.join(__dirname, '..');

const NAV_DATA = {
  'main-menu': [
    { title: 'Home', url: '/' },
    { title: 'Shop', url: '/collections/all' },
    { title: 'Best Sellers', url: '/collections/best-sellers' },
    { title: 'New Arrivals', url: '/collections/new' },
    { title: 'Bundles', url: '/collections/bundles' },
    { title: 'Apparel', url: '/collections/apparel' }
  ]
};

async function generateTheme() {

  console.log('[THEME] Generating Shopify theme...');
  console.log(`[THEME] Target: ${DOMAIN}`);
  console.log(`[THEME] Theme Name: ${THEME_NAME}`);

  await fs.ensureDir(OUTPUT_DIR);

  await fs.ensureDir(path.join(OUTPUT_DIR, 'layout'));
  await fs.ensureDir(path.join(OUTPUT_DIR, 'templates'));
  await fs.ensureDir(path.join(OUTPUT_DIR, 'sections'));
  await fs.ensureDir(path.join(OUTPUT_DIR, 'snippets'));
  await fs.ensureDir(path.join(OUTPUT_DIR, 'assets'));
  await fs.ensureDir(path.join(OUTPUT_DIR, 'config'));
  await fs.ensureDir(path.join(OUTPUT_DIR, 'locales'));

  console.log('[THEME] Copying base files...');

  const dirsToCopy = [
    'layout',
    'templates',
    'sections',
    'snippets',
    'assets',
    'config',
    'locales'
  ];

  for (const dir of dirsToCopy) {

    const srcDir = path.join(SOURCE_DIR, dir);

    if (await fs.pathExists(srcDir)) {

      await fs.copy(srcDir, path.join(OUTPUT_DIR, dir));

    }

  }

  console.log('[THEME] Updating theme settings...');

  const settingsData = {

    current: 'default',

    preset_name: `${DOMAIN} Theme`,

    presets: [
      {
        name: `${DOMAIN} Theme`,
        colors: {
          accent: '#000000',
          button_background: '#000000',
          button_label: '#ffffff',
          header: '#000000',
          header_links: '#ffffff',
          footer: '#000000',
          footer_links: '#ffffff'
        },

        fonts: {
          body: 'Helvetica Neue',
          heading: 'Helvetica Neue'
        }

      }
    ]

  };

  await fs.writeJson(
    path.join(OUTPUT_DIR, 'config', 'settings_data.json'),
    settingsData,
    { spaces: 2 }
  );

  console.log('[THEME] Creating navigation config...');

  const linklistConfig = {

    'main-menu': {
      title: 'Main Menu',
      links: NAV_DATA['main-menu']
    },

    'footer': {
      title: 'Footer',
      links: [
        { title: 'About', url: '/pages/about' },
        { title: 'Contact', url: '/pages/contact' },
        { title: 'Shipping', url: '/pages/shipping' },
        { title: 'Returns', url: '/pages/returns' }
      ]

    }

  };

  await fs.writeJson(
    path.join(OUTPUT_DIR, 'config', 'linklist.json'),
    linklistConfig,
    { spaces: 2 }
  );

  console.log('[THEME] Complete! Theme generated at:', OUTPUT_DIR);

  return OUTPUT_DIR;

}

generateTheme().catch(console.error);
