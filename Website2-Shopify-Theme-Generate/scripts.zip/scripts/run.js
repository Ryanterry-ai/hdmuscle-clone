const { execSync } = require("child_process");

const url = process.argv[2];

console.log("🚀 AI Website → Shopify Theme Generator");

if (!url) {
  console.log("❌ Missing URL");
  process.exit(1);
}

function run(script) {
  console.log(`\n▶ Running ${script}`);

  execSync(`node scripts/${script} ${url}`, {
    stdio: "inherit"
  });
}

try {

  // 1. Crawl Website
  run("crawl-site.js");

  // 2. Extract Products (must be before images)
  run("extract-products.js");

  // 3. Extract Images
  run("extract-images.js");

  // 4. Download Images
  run("download-images.js");

  // 5. Generate Shopify Theme
  run("generate-shopify-theme.js");

  // 6. Validate Theme
  run("validate-theme.js");

  // 7. Build ZIP
  run("build-theme-zip.js");

  console.log("\n✅ Pipeline Completed");

} catch (error) {

  console.error("\n❌ Pipeline Failed");
  console.error(error);

}
