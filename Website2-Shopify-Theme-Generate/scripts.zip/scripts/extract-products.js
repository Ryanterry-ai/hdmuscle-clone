const { chromium } = require("playwright")
const fs = require("fs-extra")
const path = require("path")

const TARGET_URL = process.argv[2] || "https://www.hdmuscle.com/"
const BASE_URL = TARGET_URL.replace(/\/$/, "")

const OUTPUT_FILE = path.join(
  __dirname,
  "..",
  "output",
  "extracted",
  "products.json"
)

async function extractProducts() {

console.log("[EXTRACT] Starting product extraction...")

await fs.ensureDir(path.dirname(OUTPUT_FILE))

const browser = await chromium.launch({
headless: true
})

const context = await browser.newContext({
viewport: { width: 1920, height: 1080 }
})

const page = await context.newPage()

console.log("[EXTRACT] Loading homepage...")

await page.goto(BASE_URL, {
waitUntil: "domcontentloaded",
timeout: 90000
})

await page.waitForTimeout(3000)


// Extract collections properly

const collections = await page.$$eval(
'a[href*="/collections/"]',
links =>
links
.map(link => link.href)
.filter(href => href.includes("/collections/"))
.map(href => {

const match = href.match(/\/collections\/([^\/\?]+)/)

return match ? match[1] : null

})
.filter(Boolean)
)

const uniqueCollections = [...new Set(collections)]

console.log(
`[EXTRACT] Found ${uniqueCollections.length} collections`
)

const products = []

// Loop collections

for (const collection of uniqueCollections) {

try {

const collectionUrl =
`${BASE_URL}/collections/${collection}`

console.log(
`[EXTRACT] Loading collections/${collection}...`
)

await page.goto(collectionUrl, {
waitUntil: "domcontentloaded",
timeout: 90000
})

await page.waitForTimeout(3000)


// Scroll to load lazy products

await page.evaluate(async () => {

await new Promise(resolve => {

let totalHeight = 0
const distance = 500

const timer = setInterval(() => {

window.scrollBy(0, distance)
totalHeight += distance

if (totalHeight >= document.body.scrollHeight) {

clearInterval(timer)
resolve()

}

}, 300)

})

})

await page.waitForTimeout(2000)


// Extract only product grid links

const productLinks = await page.$$eval(
'a[href*="/products/"]',
links =>
links
.map(link => ({

handle: link.href
.split("/products/")[1]
?.split("?")[0],

href: link.href,
text: link.textContent?.trim()

}))
.filter(p =>
p.handle &&
!p.handle.includes("collections") &&
!p.handle.includes("search")
)
)

productLinks.forEach(product => {

if (
!products.find(
p => p.handle === product.handle
)
) {

products.push({
...product,
collection
})

}

})

console.log(
`[EXTRACT] Found ${productLinks.length} products in ${collection}`
)

} catch (error) {

console.log(
`[EXTRACT] Error loading ${collection}: ${error.message}`
)

}

}

await browser.close()


// Remove duplicates

const uniqueProducts = products.filter(
(p, i, arr) =>
arr.findIndex(
x => x.handle === p.handle
) === i
)

await fs.writeJson(
OUTPUT_FILE,
uniqueProducts,
{ spaces: 2 }
)

console.log(
`[EXTRACT] Complete! Total unique products: ${uniqueProducts.length}`
)

console.log(
`[EXTRACT] Saved to ${OUTPUT_FILE}`
)

}

extractProducts().catch(console.error)
