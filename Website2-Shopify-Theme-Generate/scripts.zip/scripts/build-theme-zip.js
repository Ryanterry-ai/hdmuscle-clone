const fs = require('fs-extra');
const path = require('path');
const archiver = require('archiver');

const TARGET_URL = process.argv[2] || 'https://hdmuscle.com';

const DOMAIN = new URL(TARGET_URL)
  .hostname
  .replace('www.', '')
  .replace('.com', '');

const THEME_NAME = `${DOMAIN}-theme`;

const THEME_DIR = path.join(__dirname, '..', 'output', THEME_NAME);
const OUTPUT_ZIP = path.join(__dirname, '..', 'output', `${THEME_NAME}.zip`);

async function buildZip() {

  console.log('[ZIP] Building Shopify theme ZIP...');
  console.log(`[ZIP] Theme: ${THEME_NAME}`);

  if (await fs.pathExists(OUTPUT_ZIP)) {
    await fs.remove(OUTPUT_ZIP);
  }

  await fs.ensureDir(path.dirname(OUTPUT_ZIP));

  return new Promise((resolve, reject) => {

    const output = fs.createWriteStream(OUTPUT_ZIP);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => {
      console.log(`[ZIP] Complete! ${archive.pointer()} total bytes`);
      console.log(`[ZIP] Saved to: ${OUTPUT_ZIP}`);
      resolve(OUTPUT_ZIP);
    });

    archive.on('error', reject);

    archive.pipe(output);

    archive.glob('**/*', {
      cwd: THEME_DIR,
      ignore: ['assets/images/**']
    });

    archive.finalize();

  });

}

buildZip().catch(console.error);
