const fs = require("fs-extra");
const path = require("path");

const url = process.argv[2];

if (!url) {
  console.log("Missing URL");
  process.exit(1);
}

// Dynamic theme name
const domain = new URL(url).hostname.replace("www.", "");
const themeName = `${domain.split(".")[0]}-theme`;

const THEME_DIR = path.join(__dirname, "..", "output", themeName);

const REQUIRED_FILES = [
  "layout/theme.liquid",
  "sections/header.liquid",
  "sections/footer.liquid",
  "templates/index.json",
  "templates/product.json",
  "templates/collection.json",
  "assets/theme.css",
  "assets/theme.js"
];

async function validateTheme() {
  console.log("[VALIDATE] Validating Shopify theme...");
  console.log(`[VALIDATE] Theme: ${themeName}`);

  let errors = [];
  let warnings = [];

  for (const file of REQUIRED_FILES) {
    const filePath = path.join(THEME_DIR, file);

    if (await fs.pathExists(filePath)) {
      console.log(`[OK] ${file}`);
    } else {
      errors.push(`Missing: ${file}`);
      console.log(`[MISSING] ${file}`);
    }
  }

  const themeLiquidPath = path.join(THEME_DIR, "layout", "theme.liquid");

  if (await fs.pathExists(themeLiquidPath)) {
    const themeLiquid = await fs.readFile(themeLiquidPath, "utf8");

    if (themeLiquid.includes("{{ content_for_header }}")) {
      console.log("[OK] content_for_header present");
    } else {
      errors.push("Missing {{ content_for_header }}");
    }

    if (themeLiquid.includes("{{ content_for_layout }}")) {
      console.log("[OK] content_for_layout present");
    } else {
      errors.push("Missing {{ content_for_layout }}");
    }

    if (themeLiquid.includes('{% section "header" %}')) {
      console.log("[OK] header section present");
    }

    if (themeLiquid.includes('{% section "footer" %}')) {
      console.log("[OK] footer section present");
    }

  } else {
    errors.push("Missing layout/theme.liquid");
  }

  const liquidFiles = [
    "sections/header.liquid",
    "sections/footer.liquid"
  ];

  for (const file of liquidFiles) {
    const filePath = path.join(THEME_DIR, file);

    if (await fs.pathExists(filePath)) {
      const content = await fs.readFile(filePath, "utf8");

      if (content.includes("{% schema")) {
        console.log(`[OK] ${file} has schema`);
      } else {
        warnings.push(`${file} missing schema`);
      }
    }
  }

  console.log("\n=== VALIDATION RESULTS ===");

  if (errors.length === 0) {
    console.log("✅ No errors found!");
    console.log("🚀 Theme is valid for Shopify upload.");
  } else {
    console.log(`❌ ERRORS: ${errors.length}`);
    errors.forEach(e => console.log(`  - ${e}`));
  }

  if (warnings.length > 0) {
    console.log(`⚠ WARNINGS: ${warnings.length}`);
    warnings.forEach(w => console.log(`  - ${w}`));
  }

  return { valid: errors.length === 0, errors, warnings };
}

validateTheme().catch(console.error);
