const { chromium } = require('playwright');
const fs = require('fs-extra');
const path = require('path');

const TARGET_URL = process.argv[2] || process.env.TARGET_URL || 'https://www.morphogennutrition.com/';
const OUTPUT_DIR = path.join(__dirname, '..', 'output', 'crawled');
const DATA_FILE = path.join(OUTPUT_DIR, 'site-data.json');

async function crawlSite() {
  console.log(`[CRAWL] Starting crawl of ${TARGET_URL}`);
  
  await fs.ensureDir(OUTPUT_DIR);
  
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    viewport: { width: 1920, height: 1080 },
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (K1, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  });
  
  const page = await context.newPage();
  
  const siteData = {
    url: TARGET_URL,
    timestamp: new Date().toISOString(),
    pages: [],
    products: [],
    images: [],
    navigation: [],
    sections: []
  };
  
  try {
    console.log('[CRAWL] Loading main page...');
    await page.goto(TARGET_URL, { waitUntil: 'domcontentloaded', timeout: 90000 });
    await page.waitForTimeout(5000);
    await page.waitForSelector('body', { timeout: 10000 }).catch(() => {});
    
    const pageTitle = await page.title();
    console.log(`[CRAWL] Page title: ${pageTitle}`);
    
    siteData.pages.push({ url: TARGET_URL, title: pageTitle, type: 'home' });
    
    console.log('[CRAWL] Extracting navigation...');
    const navLinks = await page.$$eval('nav a, header a, .menu a, [class*="nav"] a, [class*="menu"] a', links => 
      links.map(l => ({ text: l.textContent?.trim(), href: l.href })).filter(l => l.href && l.href.startsWith('http'))
    );
    siteData.navigation = navLinks.slice(0, 50);
    console.log(`[CRAWL] Found ${navLinks.length} navigation links`);
    
    console.log('[CRAWL] Extracting product links...');
    const productLinks = await page.$$eval('a[href*="/products/"], a[href*="/collection"], a[href*="/product"]', links => 
      links.map(l => ({ text: l.textContent?.trim(), href: l.href })).filter(l => l.href && l.href.includes('hdmuscle'))
    );
    siteData.products = productLinks.slice(0, 100);
    console.log(`[CRAWL] Found ${productLinks.length} product links`);
    
    console.log('[CRAWL] Extracting images...');
    const images = await page.$$eval('img[src]', imgs => 
      imgs.map(img => ({
        src: img.src,
        alt: img.alt,
        width: img.naturalWidth,
        height: img.naturalHeight
      })).filter(img => img.src && (img.src.startsWith('http') || img.src.startsWith('/')))
    );
    siteData.images = images.slice(0, 100);
    console.log(`[CRAWL] Found ${images.length} images`);
    
    console.log('[CRAWL] Extracting sections...');
    const sections = await page.$$eval('[class*="section"], [class*="hero"], [class*="banner"], [class*="feature"], [class*="product"], [class*="footer"], [class*="header"]', els => 
      els.map(el => ({
        tag: el.tagName.toLowerCase(),
        class: el.className,
        id: el.id,
        childCount: el.children.length
      })).slice(0, 50)
    );
    siteData.sections = sections;
    console.log(`[CRAWL] Found ${sections.length} sections`);
    
    const html = await page.content();
    siteData.html = html.substring(0, 50000);
    
  } catch (error) {
    console.error('[CRAWL] Error:', error.message);
    siteData.error = error.message;
  }
  
  await browser.close();
  
  await fs.writeJson(DATA_FILE, siteData, { spaces: 2 });
  console.log(`[CRAWL] Complete! Data saved to ${DATA_FILE}`);
  console.log(`[CRAWL] Found ${siteData.products.length} products, ${siteData.images.length} images`);
  
  return siteData;
}

crawlSite().catch(console.error);